EDEBIYAT YANI BASINDA - GUNCELLEME PAKETI

DOSYALAR
- index.html: Türkiye haritası, konum bulma, eser ayrıntı penceresi ve doğrulanmış kayıt filtresi.
- admin.html: geçici içerik yönetim editörü.
- records.json: araştırma taslakları. Şimdilik bu kayıtlar haritada pin olarak gösterilmez.

GITHUB'A YUKLEME
1. GitHub'da 1emrekelebek / Edebiyat-Yaninda deposunu aç.
2. Code sekmesinde Add file > Upload files seç.
3. Bu klasördeki index.html, admin.html ve records.json dosyalarını seç.
4. index.html mevcut dosyanın yerine geçecek; diğer ikisi yeni dosya olarak eklenecek.
5. Commit changes ile kaydet.
6. GitHub Pages birkaç dakika içinde güncellenir. Siteyi sert yenile veya gizli sekmede aç.

YONETIM PANELI
Site adresinin sonuna /admin.html ekle.
Örnek: https://1emrekelebek.github.io/Edebiyat-Yaninda/admin.html
Paneldeki değişiklikler ilk aşamada yalnızca aynı tarayıcıdaki localStorage alanına kaydedilir. Diğer ziyaretçilerin görmesi için records.json dışa aktarılmalı ve GitHub deposuna yüklenmelidir.

ONEMLI GUVENLIK NOTU
Bu yönetim ekranı şifre korumalı gerçek bir yönetici paneli değildir. Statik GitHub Pages üzerinde yalnızca tarayıcı yerel hafızasını kullanan geçici bir editördür. Gerçek çok kullanıcılı ve şifreli yönetim için Supabase Auth ve veritabanı kurulmalıdır. Supabase anahtarlarının gizli olanları asla HTML/JS içine yazılmamalıdır.

KONUM
Konum özelliği HTTPS üzerinde ve kullanıcının tarayıcı/cihaz izin vermesi halinde çalışır. İzin reddedilirse tarayıcı ayarlarından bu site için Konum izni açılmalıdır. Sayfa konumu sunucuya göndermez. Konum takibi butonla başlatılır ve tekrar basılarak durdurulur.

VERI DOGRULUGU
Haritada yalnızca status=Yayında, verified=true, geçerli enlem/boylam, kaynak ve kanıt alanları dolu olan kayıtlar gösterilir. Yaklaşık, kurmaca veya kanıtlanmamış mekânlara koordinat verilmemelidir. Başlangıçtaki kayıtlar araştırma taslağıdır; kesin edebî mekân oldukları iddia edilmez.

HARITA
Leaflet ve OpenStreetMap kullanılır. Harita atıfları görünür tutulmuştur. OSM döşeme kullanım koşullarına ve atıf gerekliliklerine uyulmalıdır.
